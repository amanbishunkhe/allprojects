<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.rigorousweb.com/
 * @since      1.0.0
 *
 * @package    Social_Add_Fb
 * @subpackage Social_Add_Fb/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Social_Add_Fb
 * @subpackage Social_Add_Fb/includes
 * @author     rigorous <https://www.rigorousweb.com/>
 */
class Social_Add_Fb_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
