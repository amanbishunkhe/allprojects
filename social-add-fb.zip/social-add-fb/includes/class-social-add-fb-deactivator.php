<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://www.rigorousweb.com/
 * @since      1.0.0
 *
 * @package    Social_Add_Fb
 * @subpackage Social_Add_Fb/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Social_Add_Fb
 * @subpackage Social_Add_Fb/includes
 * @author     rigorous <https://www.rigorousweb.com/>
 */
class Social_Add_Fb_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
