<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://www.rigorousweb.com/
 * @since      1.0.0
 *
 * @package    Social_Add_Fb
 * @subpackage Social_Add_Fb/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Social_Add_Fb
 * @subpackage Social_Add_Fb/public
 * @author     rigorous <https://www.rigorousweb.com/>
 */
class Social_Add_Fb_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		$this->establish_location();
		

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Social_Add_Fb_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Social_Add_Fb_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/social-add-fb-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Social_Add_Fb_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Social_Add_Fb_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/social-add-fb-public.js', array( 'jquery' ), $this->version, false );

	}

	public function establish_location() {
        //* Establish a default.
        $this->location = 'none';
       
	}



	public function the_content( $post_content ) {		
		$position  	= get_option( 'social_add_fb_position');
		$html       = '';

		ob_start();
			include_once 'partials/social-add-fb-public-display.php';			
		$social = ob_get_clean();

		if( 'top' == $position){
			$html .= $social;
		}

		$html .= $post_content;

		if( 'below' === $position ) {
			$html .= $social;
		}

		if( 'bottom' === $position ) {
			$html .= $social;
		}		

		return $html;			
	}

	/*
	public function the_content_display()
	{
		$position  = get_option( 'social_add_fb_position');			
			//var_dump($position);
			$url =  get_the_permalink( $post = 0 );
			$fb_iframe = '<iframe src="https://www.facebook.com/plugins/share_button.php?href='. $url .'%2Fdocs%2Fplugins%2F&layout=button_count&size=small&mobile_iframe=true&width=88&height=20&appId" width="88" height="20" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe> ';
			

			if($position == 'top')
			{	
				?>
	                <div class="fb-logo-top"> 	
	                	<?php echo $fb_iframe;?>	                	
	                </div>                        
				<?php
			}
			else if($position == 'right')
			{
				?>
					<div class="fb-logo-right"> 	
	                	<?php echo $fb_iframe;?>	                	
	                </div>
				<?php
				//$post_content = 'right';
			}
			else if($position == 'left')
			{
				?>
					<div class="fb-logo-left"> 	
	                	<?php echo $fb_iframe;?>	                	
	                </div>
				<?php
				//$post_content = 'left';
			}
			else
			{
				?>
					<div class="fb-logo-below"> 	
	                	<?php echo $fb_iframe;?>	                	
	                </div>
				<?php
				//$post_content = 'below';
			}
			 
	}
	*/



}
