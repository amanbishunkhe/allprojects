<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://www.rigorousweb.com/
 * @since      1.0.0
 *
 * @package    Social_Add_Fb
 * @subpackage Social_Add_Fb/public/partials
 * 
 */		
		// If we are on the home page
		if( is_home() || is_front_page() || is_page_template() ):
            return;
        endif;
       
		//echo is_singular();
		$position  				= get_option( 'social_add_fb_position');	
		$position_top_margin  	= get_option( 'social_add_fb_position_top_margin');	
		$position_below_margin  = get_option( 'social_add_fb_position_below_margin');
		$page_post_option 		= get_option('social_add_fb_choose_page_post');
		$absolute_fixed_option  = get_option('social_add_fb_choose_absolute_fixed');

		$url 					=  get_the_permalink( );
		// $fb_iframe 				= '<iframe src="https://www.facebook.com/plugins/share_button.php?href='. esc_url( $url ) .'&layout=button_count&size=large&mobile_iframe=true&width=88&height=20&appId" width="88" height="20" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe> ';

		$fb_iframe = '<iframe src="https://www.facebook.com/plugins/share_button.php?href='. esc_url( $url ) .'&layout=button_count&size=large&mobile_iframe=false&appId=559112917768409&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>';

		$position_class 		= '';
		$position_class_margin 	= '';

		if($position == 'top')
			{	
				$position_class = 'fb-logo-top';
				$position_class_margin = 'style="top:'.$position_top_margin.'px"';
				$top_margin_bottom = 'style="margin-bottom:'.$position_top_margin.'px"';

				if($absolute_fixed_option == 'fixed')
				{
					$fixed_or_absolute = 'fb-top-fixed';
				}
				else
				{
					$fixed_or_absolute = 'fb-top-absolute';
				}
				
			}			
			else if($position == 'below')
			{				
				$position_class = 'fb-logo-below';
				$position_class_margin = 'style="bottom:'.$position_below_margin.'px"';
			}
			else
			{
				$position_class = 'fb-logo-bottom';
			}

		switch($page_post_option)
		{
			case 'page':
				if( is_page() == true ) {
					?>	
					<div class="unique-container" ></div>
					<div class="<?php echo $position_class;?>"  <?php echo $top_margin_bottom;?>>
						<div class="fb-btn-wrapper<?php echo $fixed_or_absolute ;?>" style="max-width: 1080px" <?php echo $position_class_margin;?> >
							<?php echo $fb_iframe; ?>
						</div>
					</div>
					<?php										
				}
			break;

			case 'both':
					?>
					<div class="unique-container"></div>
					<div class="<?php echo $position_class;?>"  <?php echo $top_margin_bottom;?>>
						<div class="fb-btn-wrapper<?php echo $fixed_or_absolute ;?>" style="max-width: 1080px" <?php echo $position_class_margin;?> >
							<?php echo $fb_iframe; ?>
						</div>
					</div>
					<?php
			break;

			case 'post':
				if( is_singular() == true ){
					?>
						<div class="unique-container"></div>
						<div class="<?php echo $position_class;?>"  <?php echo $top_margin_bottom;?>>
							<div class="fb-btn-wrapper<?php echo $fixed_or_absolute ;?>" <?php echo $position_class_margin;?> style="max-width: 1080px" >
								<?php echo $fb_iframe; ?>
							</div>
						</div>
					<?php
				}
			break;
			default:			
		}
			 
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
