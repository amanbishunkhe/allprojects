(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */


	 $(function(){

	 		var $shareIcon = $('.fb-logo-top');
	 		if($shareIcon.length)
	 		{
		 		var $shareOffsetTop = $('.fb-logo-top').offset().top;
		 		var $win = $(window);

		 		$win.on('scroll', function(e){
		 			var $this = $(this);

		 			if( $this.scrollTop() > $shareOffsetTop ) {
		 				$('body').addClass('share-fixed');
		 			} else {
		 				$('body').removeClass('share-fixed');
		 			}
		 		});
	 		}
	 		
	 });

	 $(function(){
	 		var $shareIcon1 = $('.fb-logo-below');
	 		if($shareIcon1.length)
	 		{
		 		var $shareOffsetTop1 = $('.fb-logo-below').parent().offset().top - 300;
		 		var $shareOffsetTop2 = $('.unique-container').offset().top - 600;
		 		var $win1 = $(window);
		 		$win1.on('scroll', function(e){
		 			var $this = $(this);

		 			if( $(window).scrollTop() > $shareOffsetTop2 ) {
		 				$('body').removeClass('share-fixed');
		 			} else if( $(window).scrollTop() > $shareOffsetTop1 ) {
		 				$('body').addClass('share-fixed');
		 			} else {
		 				$('body').removeClass('share-fixed');
		 			}
		 		});
	 		}
	 		
	 });

})( jQuery );
