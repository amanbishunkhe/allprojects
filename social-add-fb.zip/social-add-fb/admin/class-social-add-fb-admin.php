<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://www.rigorousweb.com/
 * @since      1.0.0
 *
 * @package    Social_Add_Fb
 * @subpackage Social_Add_Fb/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Social_Add_Fb
 * @subpackage Social_Add_Fb/admin
 * @author     rigorous <https://www.rigorousweb.com/>
 */
class Social_Add_Fb_Admin {
	/**
	 * The options name to be used in this plugin
	 *
	 * @since  	1.0.0
	 * @access 	private
	 * @var  	string 		$option_name 	Option name of this plugin
	 */
	private $option_name = 'social_add_fb';

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Social_Add_Fb_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Social_Add_Fb_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/social-add-fb-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Social_Add_Fb_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Social_Add_Fb_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/social-add-fb-admin.js', array( 'jquery' ), $this->version, false );

	}

	public function fb_share_metabox() {
		add_meta_box( 
			'fb_share_buttons', 
			'Facebook Share', 
			array( $this, 'fb_share_shortcode_view' ), 
			'post', 
			'normal', 
			'default'
		);

	}

	public function fb_share_shortcode_view($post)
	{
		global $post;
		
		$position = get_post_meta( $post->ID, '_fb_share_button_position', true );
		wp_nonce_field( 'fb_share_buttons', 'fb_share_buttons_nonce' );
		
		?>
		<fieldset>
			<label><h1><?php _e('Inline Share Buttons','social_add_fb');?></h1></label>
			<br>
			<label>
				<input <?php checked( 'top', $position, true ); ?> type="radio" name="_fb_share_button_position"  value="[top]">
				<?php _e( 'Include at top of post content', 'social-add-fb' ); ?>
			</label>

			<br>
			<label>
				<input <?php checked( 'bottom', $position, true ); ?> type="radio" name="_fb_share_button_position"  value="[bottom]">
				<?php _e( 'Include at bottom of post content', 'social-add-fb' ); ?>
			</label>
			<br>

		    <label ">
			   	<input type="text" name="" placeholder="[share-this-inline-buttons]"><br>
  				<input type="hidden" name="result_position" value="result_position_<?php echo $position; ?>" ><br>
  				<?php _e( 'Inline Share Button Shortcode', 'social-add-fb' ); ?>
		    </label>

		</fieldset>
		


		<?php
	}


	public function social_share_metabox_save( $post_id ){

		//echo 'saving metabox'; die();
		 // Checks save status
	    $is_autosave = wp_is_post_autosave( $post_id );
	    $is_revision = wp_is_post_revision( $post_id );
	    $is_valid_nonce = ( isset( $_POST[ 'fb_share_buttons' ] ) && wp_verify_nonce( $_POST[ 'fb_share_buttons' ], 'fb_share_buttons_nonce' ) ) ? 'true' : 'false';
	 
	    // Exits script depending on save status
	    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
	        return $post_id;
	    }
	    $position = $_POST['_fb_share_button_position'];
	    update_post_meta( $post_id, '_fb_share_button_position', $position );
 
    }

    public function fb_sharing_shortcode()
    {
    	echo 'shortcode';
    }

	function fb_social_admin_menu()
	{
		$this->plugin_screen_hook_suffix = add_options_page(
			__( 'Facebook  Share Settings', 'facebook-share-button' ),
			__( 'Facebook Share', 'facebook-share-button' ),
			'manage_options',
			$this->plugin_name,
			array( $this, 'display_options_page' )
		);
	}

	/**
	 * Render the options page for plugin
	 *
	 * @since  1.0.0
	 */
	public function display_options_page() {
		include_once 'partials/social-add-fb-admin-display.php';
	}
	public function register_setting ()
	{
			// Add a General section
			add_settings_section(
				$this->option_name . '_general',
				__( 'General', 'social-add-fb' ),
				array( $this, $this->option_name . '_general' ),
				$this->plugin_name
			);

			add_settings_field(
				$this->option_name . '_position',
				__( 'Facebook Share Button Position', 'social-add-fb' ),
				array( $this, $this->option_name . '_position' ),
				$this->plugin_name,
				$this->option_name . '_general',
				array( 'label_for' => $this->option_name . '_position' )
			);

			add_settings_field(
				$this->option_name . '_position_top_margin',
				__( 'Facebook Share Top Position Margin ( Enter required pixel here, if you have selected top Position from above options)', 'social-add-fb' ),
				array( $this, $this->option_name . '_position_top_margin' ),
				$this->plugin_name,
				$this->option_name . '_general',
				array( 'label_for' => $this->option_name . '_position_top_margin' )
			);


			add_settings_field( 
				$this->option_name . '_choose_absolute_fixed',
				__( 'Choose  share button to keep scroll with post or fixed in top position', 'social-add-fb' ),
				array( $this, $this->option_name . '_choose_absolute_fixed' ),
				$this->plugin_name,
				$this->option_name . '_general',
				array( 'label_for' => $this->option_name . '_choose_absolute_fixed' )
				
			);

			// add_settings_field(
			// 	$this->option_name . '_position_below_margin',
			// 	__( 'Facebook Share below Position Margin ( Enter required pixel here, if you have selected below Position from above options)', 'social-add-fb' ),
			// 	array( $this, $this->option_name . '_position_below_margin' ),
			// 	$this->plugin_name,
			// 	$this->option_name . '_general',
			// 	array( 'label_for' => $this->option_name . '_position_below_margin' )
			// );


			add_settings_field( 
				$this->option_name . '_choose_page_post',
				__( 'Choose to display share button in page or post', 'social-add-fb' ),
				array( $this, $this->option_name . '_choose_page_post' ),
				$this->plugin_name,
				$this->option_name . '_general',
				array( 'label_for' => $this->option_name . '_choose_page_post' )
				
			);


			register_setting( $this->plugin_name, $this->option_name . '_position', array( $this, $this->option_name . '_sanitize_position' ) );

			register_setting( $this->plugin_name, $this->option_name . '_position_top_margin', 'intval' );

			// register_setting( $this->plugin_name, $this->option_name . '_position_below_margin', 'intval' );

			register_setting( $this->plugin_name, $this->option_name . '_choose_page_post',array( $this, $this->option_name . '_sanitize_choose_page_post' ));

			register_setting( $this->plugin_name, $this->option_name . '_choose_absolute_fixed',array( $this, $this->option_name . '_sanitize_choose_absolute_fixed' ));

			
	}
	public function social_add_fb_general() {
		echo '<h2>' . __( 'Change the settings accordingly.', 'social-add-fb' ) . '</h2>';
	}

	public function social_add_fb_position()
	{
		$position = get_option( $this->option_name . '_position','top' );
		
		?>
			<fieldset>
				<label>
					<input type="radio" name="<?php echo $this->option_name . '_position' ?>" id="<?php echo $this->option_name . '_position' ?>" value="top" <?php checked( $position, 'top' ); ?>>
					<?php _e( 'Top', 'social-add-fb' ); ?>
				</label>					
				
				<label>
					<input type="radio" name="<?php echo $this->option_name . '_position' ?>" value="below" <?php checked( $position, 'below' ); ?>>
					<?php _e( 'Below', 'social-add-fb' ); ?>
				</label>

				<label>
					<input type="radio" name="<?php echo $this->option_name . '_position' ?>" value="bottom" <?php checked( $position, 'bottom' ); ?>>
					<?php _e( 'bottom', 'social-add-fb' ); ?>
				</label>

			</fieldset>
		<?php
	
	}

	public function social_add_fb_sanitize_position( $position ) {
		if ( in_array( $position, array( 'top','below','bottom' ), true ) ) {
	        return $position;
	    }
	}

	public function social_add_fb_position_top_margin()
	{
		$position_top_margin = get_option( $this->option_name . '_position_top_margin','72' );
		echo '<input type="number" name="' . $this->option_name . '_position_top_margin' . '" id="' . $this->option_name . '_position_top_margin' . '" value="' . $position_top_margin . '"> ' . __( 'px', 'social-add-fb' );
		//	var_dump(get_option( $this->option_name . '_position_top_margin' ));
		
	}

	// public function social_add_fb_position_below_margin()
	// {
	// 	$position_below_margin = get_option( $this->option_name . '_position_below_margin','20' );

	// 	echo '<input type="number" name="' . $this->option_name . '_position_below_margin' . '" id="' . $this->option_name . '_position_below_margin' . '" value="' . $position_below_margin . '"> ' . __( 'px', 'social-add-fb' );
	// 	//	var_dump(get_option( $this->option_name . '_position_below_margin' ));
	// }
	

	public function social_add_fb_choose_page_post()
	{
		$choose_page_option = get_option( $this->option_name . '_choose_page_post','post' );
		?>
			<fieldset>
				<label>
					<input type="radio" name="<?php echo $this->option_name . '_choose_page_post' ?>" value="page" <?php checked( $choose_page_option, 'page' ); ?>>
					<?php _e( 'Page', 'social-add-fb' ); ?>
				</label>

				<label>
					<input type="radio" name="<?php echo $this->option_name . '_choose_page_post' ?>" value="post" <?php checked( $choose_page_option, 'post' ); ?>>
					<?php _e( 'Post', 'social-add-fb' ); ?>
				</label>

				<label>
					<input type="radio" name="<?php echo $this->option_name . '_choose_page_post' ?>" value="both" <?php checked( $choose_page_option, 'both' ); ?>>
					<?php _e( 'Both', 'social-add-fb' ); ?>
				</label>

			</fieldset>
		<?php
	//	var_dump(get_option( $this->option_name . '_choose_page_post' ));
	}
	public function social_add_fb_sanitize_choose_page_post( $choose_page_option ) {
		if ( in_array( $choose_page_option, array( 'page', 'post','both'), true ) ) {
	        return $choose_page_option;
	    }
	}

	public function social_add_fb_choose_absolute_fixed()
	{
		$choose_absolute_fixed = get_option( $this->option_name . '_choose_absolute_fixed','fixed' );
		?>
			<fieldset>

				<label>
					<input type="radio" name="<?php echo $this->option_name . '_choose_absolute_fixed' ?>" value="absolute" <?php checked( $choose_absolute_fixed, 'absolute' ); ?>>
					<?php _e( 'Scroll with post', 'social-add-fb' ); ?>
				</label>

				<label>
					<input type="radio" name="<?php echo $this->option_name . '_choose_absolute_fixed' ?>" value="fixed" <?php checked( $choose_absolute_fixed, 'fixed' ); ?>>
					<?php _e( 'Fixed', 'social-add-fb' ); ?>
				</label>
				
			</fieldset>
		<?php
		//var_dump(get_option( $this->option_name . '_choose_absolute_fixed' ));
	}

	public function social_add_fb_sanitize_choose_absolute_fixed( $choose_absolute_fixed ) {
		if ( in_array( $choose_absolute_fixed, array( 'absolute', 'fixed'), true ) ) {
	        return $choose_absolute_fixed;
	    }
	}


}
