<?php

/**
* Registers a new post type
* @uses $wp_post_types Inserts new post type object into the list
*
* @param string  Post type key, must not exceed 20 characters
* @param array|string  See optional args description above.
* @return object|WP_Error the registered post type object, or an error object
*/
function rws_ourmentor_posttype() {

    $labels = array(
        'name'                => __( 'Our Mentors', 'rws-aep' ),
        'singular_name'       => __( 'Our Mentor', 'rws-aep' ),
        'add_new'             => _x( 'Add New Our Mentor', 'rws-aep', 'rws-aep' ),
        'add_new_item'        => __( 'Add New Our Mentor', 'rws-aep' ),
        'edit_item'           => __( 'Edit Our Mentor', 'rws-aep' ),
        'new_item'            => __( 'New Our Mentor', 'rws-aep' ),
        'view_item'           => __( 'View Our Mentor', 'rws-aep' ),
        'search_items'        => __( 'Search Our Mentors', 'rws-aep' ),
        'not_found'           => __( 'No Our Mentors found', 'rws-aep' ),
        'not_found_in_trash'  => __( 'No Our Mentors found in Trash', 'rws-aep' ),
        'parent_item_colon'   => __( 'Parent Our Mentor:', 'rws-aep' ),
        'menu_name'           => __( 'Our Mentors', 'rws-aep' ),
    );

    $args = array(
        'labels'              => $labels,
        'hierarchical'        => false,
        'description'         => 'Custom Post Type Created for Our Mentors',
        'taxonomies'          => array(),
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => null,
        'menu_icon'           => 'dashicons-id',
        'show_in_nav_menus'   => true,
        'publicly_queryable'  => false, //set false to remove View btn
        'exclude_from_search' => false,
        'has_archive'         => true,
        'query_var'           => true,
        'can_export'          => true,
        'rewrite'             => true,
        'capability_type'     => 'post',
        'supports'            => array( 'title', 'editor', 'thumbnail', 'post-formats')
    );

    register_post_type( 'ourmentor', $args );
}

add_action( 'init', 'rws_ourmentor_posttype' );


add_filter('manage_ourmentor_posts_columns', 'rws_head_only_ourmentors');
add_action('manage_ourmentor_posts_custom_column', 'rws_content_only_ourmentors', 10, 2);
 
//adding column in the listing of the our mentors
function rws_head_only_ourmentors($defaults) {
    $defaults['featured_image'] = 'Mentor Image';
    return $defaults;
}
function rws_content_only_ourmentors($column_name, $post_ID) {
    if ($column_name == 'featured_image') {
        $post_thumbnail_id = get_post_thumbnail_id($post_ID);
        if ($post_thumbnail_id) {
            $post_thumbnail_img = wp_get_attachment_image_src($post_thumbnail_id, 'featured_preview');
            echo "<img src='".$post_thumbnail_img[0]."' width='80'/>";
        }
    }
}

// set metaboxes
function rws_ourmentors_metabox_options( $options ) {
    $options[]    = array(
        'id'        => 'our_mentor_meta',
        'title'     => 'Our Mentors Others Details',
        'post_type' => 'ourmentor',
        'context'   => 'normal',
        'priority'  => 'default',
        'sections'  => array(
            array(
                'name'  => 'general',
                //'title' => 'General',
                //'icon'  => 'fa fa-cog',
                'fields' => array(
                    array(
                        'id'        => 'mentor_designation',
                        'type'      => 'text',
                        'title'     => 'Mentor Designation',
                        'add_title' => 'Mentor Designation',
                    ),
                    array(
                        'id'        => 'mentor_linkendin_id',
                        'type'      => 'text',
                        'title'     => 'Mentor linkedin',
                        'add_title' => 'Mentor linkedin ID',
                    ),
                    array(
                        'id'        => 'mentor_date',
                        'type'      => 'text',
                        'title'     => 'Mentor date',
                        'add_title' => 'Mentor date ',
                    ),
                ), // END fields
            ), // END section
        ), // END sections
    ); // END $options
    return $options;
}
add_filter( 'cs_metabox_options', 'rws_ourmentors_metabox_options' );
